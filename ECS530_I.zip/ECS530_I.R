
## ---- echo=TRUE-------------------------------------------------------------------------
needed <- c("raster", "stars", "abind", "elevatr", "sp", "mapview", "sf", "osmdata")


## ---- echo = TRUE-----------------------------------------------------------------------
suppressPackageStartupMessages(library(osmdata))
library(sf)


## ---- cache=TRUE, echo = TRUE-----------------------------------------------------------
bbox <- opq(bbox = 'bergen norway')
byb0 <- osmdata_sf(add_osm_feature(bbox, key = 'railway',
  value = 'light_rail'))$osm_lines
tram <- osmdata_sf(add_osm_feature(bbox, key = 'railway',
  value = 'tram'))$osm_lines
byb1 <- tram[!is.na(tram$name),]
o <- intersect(names(byb0), names(byb1))
byb <- rbind(byb0[,o], byb1[,o])


## ---- echo = TRUE-----------------------------------------------------------------------
library(mapview)
mapview(byb)


## ---- echo = TRUE-----------------------------------------------------------------------
library(sp)
byb_sp <- as(byb, "Spatial")
str(byb_sp, max.level=2)


## ---- echo = TRUE-----------------------------------------------------------------------
str(slot(byb_sp, "lines")[[1]])


## ---- echo = TRUE, cache=TRUE, eval=FALSE-----------------------------------------------
library(elevatr)
elevation <- get_elev_raster(byb_sp, z = 14)


## ---- echo = TRUE, eval=TRUE------------------------------------------------------------
str(elevation, max.level=2)


## ---- echo=TRUE-------------------------------------------------------------------------
str(as(elevation, "SpatialGridDataFrame"), max.level=2)


## ---- echo = TRUE, eval=FALSE-----------------------------------------------------------
mapview(elevation, col=terrain.colors)


## ---- echo = TRUE-----------------------------------------------------------------------
V1 <- 1:3
V2 <- letters[1:3]
V3 <- sqrt(V1)
V4 <- sqrt(as.complex(-V1))
L <- list(v1=V1, v2=V2, v3=V3, v4=V4)


## ---- echo = TRUE-----------------------------------------------------------------------
str(L)
L$v3[2]
L[[3]][2]


## ---- echo = TRUE-----------------------------------------------------------------------
DF <- as.data.frame(L)
str(DF)
DF <- as.data.frame(L, stringsAsFactors=FALSE)
str(DF)


## ---- echo = TRUE-----------------------------------------------------------------------
V2a <- letters[1:4]
V4a <- factor(V2a)
La <- list(v1=V1, v2=V2a, v3=V3, v4=V4a)
DFa <- try(as.data.frame(La, stringsAsFactors=FALSE), silent=TRUE)
message(DFa)


## ---- echo = TRUE-----------------------------------------------------------------------
DF$v3[2]
DF[[3]][2]
DF[["v3"]][2]


## ---- echo = TRUE-----------------------------------------------------------------------
DF[2, 3]
DF[2, "v3"]
str(DF[2, 3])
str(DF[2, 3, drop=FALSE])


## ---- echo = TRUE-----------------------------------------------------------------------
as.matrix(DF)
as.matrix(DF[,c(1,3)])


## ---- echo = TRUE-----------------------------------------------------------------------
length(L)
length(DF)
length(as.matrix(DF))


## ---- echo = TRUE-----------------------------------------------------------------------
dim(L)
dim(DF)
dim(as.matrix(DF))


## ---- echo = TRUE-----------------------------------------------------------------------
str(as.matrix(DF))


## ---- echo = TRUE-----------------------------------------------------------------------
row.names(DF)
names(DF)
names(DF) <- LETTERS[1:4]
names(DF)
str(dimnames(as.matrix(DF)))


## ---- echo = TRUE-----------------------------------------------------------------------
str(attributes(DF))
str(attributes(as.matrix(DF)))


## ---- echo = TRUE-----------------------------------------------------------------------
V1a <- c(V1, NA)
V3a <- sqrt(V1a)
La <- list(v1=V1a, v2=V2a, v3=V3a, v4=V4a)
DFa <- as.data.frame(La, stringsAsFactors=FALSE)
str(DFa)


## ---- echo = TRUE-----------------------------------------------------------------------
DF$E <- list(d=1, e="1", f=TRUE)
str(DF)


## ---- echo = TRUE-----------------------------------------------------------------------
pt1 <- st_point(c(1,3))
pt2 <- pt1 + 1
pt3 <- pt2 + 1
str(pt3)


## ---- echo = TRUE-----------------------------------------------------------------------
st_as_text(pt3)


## ---- echo = TRUE-----------------------------------------------------------------------
st_as_binary(pt3)


## ---- echo = TRUE-----------------------------------------------------------------------
pt_sfc <- st_as_sfc(list(pt1, pt2, pt3))
str(pt_sfc)


## ---- echo = TRUE-----------------------------------------------------------------------
st_geometry(DF) <- pt_sfc
(DF)


## ---- echo = TRUE-----------------------------------------------------------------------
(buf_DF <- st_buffer(DF, dist=0.3))


## ---- echo = TRUE-----------------------------------------------------------------------
library(stars)
fn <- system.file("tif/L7_ETMs.tif", package = "stars")
L7 <- read_stars(fn)
L7


## ---- echo = TRUE-----------------------------------------------------------------------
ndvi <- function(x) (x[4] - x[3])/(x[4] + x[3])
(s2.ndvi <- st_apply(L7, c("x", "y"), ndvi))


## ---- echo = TRUE-----------------------------------------------------------------------
L7p <- read_stars(fn, proxy=TRUE)
L7p


## ---- echo = TRUE-----------------------------------------------------------------------
(L7p.ndvi = st_apply(L7p, c("x", "y"), ndvi))


## ---- echo = TRUE-----------------------------------------------------------------------
(x6 <- split(L7, "band"))


## ---- echo = TRUE-----------------------------------------------------------------------
x6$mean <- (x6[[1]] + x6[[2]] + x6[[3]] + x6[[4]] + x6[[5]] +
              x6[[6]])/6
xm <- st_apply(L7, c("x", "y"), mean)
all.equal(xm[[1]], x6$mean)

